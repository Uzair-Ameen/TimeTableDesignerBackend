package com.project.demo;

import lombok.Data;



public @Data
class PlacementDto {


    private String teacherName;


    private String courseID;


    private String department;

    private int batch;

    private int section;

    private int format;
}
