package com.project.demo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoomplacementsRepository extends JpaRepository<Roomplacements, Integer> {
}
